import time

from profundidad_y_poda import branchAndBound
from TSP import TSP

# Sirve como base para que haya un primer vistazo a como se trabajaría
if __name__ == '__main__':
    # tsp = TSP() #Crear el objeto
    #fichero = "ulysses16.tsp"
    # tsp.obtener_desde_archivo_tsp(fichero)  #Lee de un archivo .tsp

    print("----------------------------------------------------------------------------------")
    print("-----------------------------PRUEBAS BACKTRACKING---------------------------------------")
    print("----------------------------------------------------------------------------------")
    for _ in range(10):
        print("..............Iteracion: " + str(_) +
              "..............................")
        for i in range(2, 13):
            tsp = TSP()
            tsp.obtener_random(i)
            tsp.backtracking_solve()
            # tsp.draw_with_solution()

    # print("----------------------------------------------------------------------------------")
    # print("-----------------------------PRUEBAS GREEDY---------------------------------------")
    # print("----------------------------------------------------------------------------------")
    # for i in range(200,5001, 10):
    #     tsp = TSP()
    #     tsp.obtener_random(i) #Genera un escenario aleatorio de la dimension que le pases
    #     tsp.greedy_solve()

    #         #Genera una solucion de ruta
    #         #tsp.draw_with_solution() #dibujar la solucion
    #         #tsp.draw() #dibujar solo las ciudades
    #         #tsp.opt2()
    #         #tsp.draw_with_solution() #dibujar la solucion

    #         #tsp.aplicar_mejor_solucion_desde_archivo()
    #         #tsp.draw_with_solution()
    #         #tsp.shuffle()

    #         #tsp.draw_with_solution()
    #         #branchAndBound(tsp)
    #         #tsp.draw_with_solution()

    # print("----------------------------------------------------------------------------------")
    # print("-----------------------------PRUEBAS OPT2---------------------------------------")
    # print("----------------------------------------------------------------------------------")
    # for _ in range(5):
    #     print("..............Iteracion: " + str(_) + "..............................")
    #     for i in range(2, 101):
    #         tsp = TSP()
    #         tsp.obtener_random(i)
    #         tsp.opt2()

    # for i in range(100, 201):
    #     tsp = TSP()
    #     tsp.obtener_random(i)
    #     tsp.opt2()

    # print("----------------------------------------------------------------------------------")
    # print("-----------------------------PRUEBAS BRANCH & BOUND---------------------------------------")
    # print("----------------------------------------------------------------------------------")
    # for _ in range(20):
    #     print("..............Iteracion: " + str(_) + "..............................")
    #     for i in range(2,15):
    #         tsp = TSP()
    #         tsp.obtener_random(i)
    #         branchAndBound(tsp)

    # No se recomienda probar el backtracking con el archivo .tsp,
    # si este tiene demasiadas dimensiones empezar con generaciones
    # aleatorias y tratar de reducir la computacion con podas y/o heuristicas.
    # La complejidad crece muy rápidamente y se puede bloquear el ordenador.

    # tsp.backtracking_solve()
    # tsp.draw_with_solution()
